<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="all">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Title</title>

    <!-- Bootstrap -->
    <link href="<?php 	echo url_for('css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php 	echo url_for('css/styles.css'); ?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo url_for('js/bootstrap.min.js');?>"></script>
     <script src="<?php echo url_for('js/dropimage.js');?>"></script>
  </head>
 

    
<body>
<script>
FB.getLoginStatus(function(response) {
    statusChangeCallback(response);
});
{
    status: 'connected',
    authResponse: {
        accessToken: '...',
        expiresIn:'...',
        signedRequest:'...',
        userID:'...'
    }
}
 window.fbAsyncInit = function() {
    FB.init({
      appId      : '839446722815068',
      xfbml      : true,
      version    : 'v2.3'
    });
  };
  function checkLoginState() {
  
  FB.getLoginStatus(function(response) {
    statusChangeCallback(response);
  });
}
FB.login(function(response) {
   // handle the response
 }, {scope: 'public_profile,email'});

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<div class="row">
	<nav class="nav navbar navbar-default">
		<div class="col-md-3 textcolororg"><a class="textcolororg"	href="dashboard.php">	<h4>GRANDMAS RECIPES&trade;</h4></a></div>
         	        <div class="col-md-3 searchpadding">
	            <form action="" class="search-form">
	                <div class="form-group has-feedback">
	            		<label for="search" class="sr-only">Search</label>
	            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
	              		<span class="glyphicon glyphicon-search form-control-feedback" style="color: #f57e20;"></span>
	            	</div>
	            </form>
	        </div>
		  	<div class="col-md-2 textcolororg">
		  		<h4 data-toggle="dropdown" class="myrec">My Recipes</h4>
		  		<ul class="dropdown-menu " style="margin: 16px 0 0 -26px;" role="menu">
				    <li><a href="<?php echo url_for('add_recipe.php');?>">Add New</a></li>
				    <li class="exdivider"></li>
				    <li><a href="all_recipes.php">View All</a></li>
				  </ul>
		  	</div>
		  	<div class="col-md-2 textcolororg">
		  		<h4 data-toggle="dropdown" class="family">Family Members</h4>
		  		<ul class="dropdown-menu" style="margin: 16px 0 0 28px;" role="menu">
				    <li><a href="#">Invite New</a></li>
				    <li class="exdivider"></li>
				    <li><a href="#">View All</a></li>
				  </ul>
		  	</div>
		  	<div class="col-md-2"><!-- Single button -->
				<div class="btn-group">
				  <button type="button" class="glyphicon glyphicon-user dropdown-toggle user" data-toggle="dropdown" aria-expanded="false">
				  </button>
				  <ul class="dropdown-menu" role="menu">
				    <li><a href="#">Action</a></li>
				    <li><a href="#">Another action</a></li>
				    <li><a href="#">Something else here</a></li>
				    <div class="userbtm">
				    <li><a href="#">Separated link</a></li>
				    </div>
				  </ul>
				</div>
</div>
		  	
		</div>
	</nav>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php 	echo url_for('js/bootstrap.min.js');?>"></script>
  