<table class="table table-striped">
	  
	  	<tr class="trowlgray">
	  		<td class="smalltcom">
	  			<input type="" placeholder="4" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="smalltcom">
	  			<input type="" placeholder="Tbs" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="blanktcom"></td>
	  		<td>
	  			<input name="ingredient" type="text" class="form-control trowlgray" placeholder="Suger" aria-describedby="sizing-addon1">
	  		</td>
	  		
	  		<td class="exsmalltcom">
	  			<a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a>
	  		</td>	
	  	</tr>
	  	
	  	<tr class="trowdgray">
	  		<td class="smalltcom">
	  			<input type="" class="form-control trowdgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="smalltcom">
	  			<input type="" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="blanktcom"></td>
	  		<td>
	  			<input name="ingredient" type="text" class="form-control trowdgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="exsmalltcom">
	  			<a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a>
	  		</td>	
	  	</tr>
	  	
	  	<tr class="trowlgray">
	  		<td class="smalltcom">
	  			<input type="" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="smalltcom">
	  			<input type="" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="blanktcom"></td>
	  		<td>
	  			<input name="ingredient" type="text" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="exsmalltcom">
	  			<a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a>
	  		</td>	
	  	</tr>
	  </table>