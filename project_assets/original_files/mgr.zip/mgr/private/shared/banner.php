<div class="row foodbanner">
	<div class="col-sm-7 col-sm-offset-3 transgray">
		<div class="row">	
			<div class="col-sm-4 col-sm-offset-4"><h1>Your Recipes</h1></div>
		</div>
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3 underline-white"></div>	
		</div>
		<div class="row"><div class="col-sm-6 col-sm-offset-3">
			<h5>Find your recipe
			<form action="" class="search-form">
	                <div class="form-group has-feedback">
	            		<label for="search" class="sr-only">Search</label>
	            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
	              		<span class="glyphicon glyphicon-search form-control-feedback" style="color: #f57e20;"></span>
	            	</div>
	            </form>
</h5></div></div>	
	</div>
</div>