<?php 
	define("DB_SERVER" , "localhost");
	define("DB_USER" , "bellsweb_mgr");
	define("DB_PASS" , "Azsxdcfvgb1!");
	define("DB_NAME" , "bellsweb_mgr");
?>	