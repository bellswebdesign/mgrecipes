<?php 
	function find_all_recipes(){
		global $db;
		
		$sql = "SELECT * FROM Recipe ";
		//echo $db . " <br />";	
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;
	}
		
	
	function find_recipe_by_id($id){
		global $db;
		
		$sql = "SELECT * FROM Recipe ";
		$sql .= "WHERE id='" . $id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		$recipe = mysqli_fetch_assoc($result);
		return $recipe; // returns an assoc. array
	}
	
	function find_all_measures(){
		global $db;
		$sql = "SELECT * FROM Measure ";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;		
	}
	
	function find_measure_by_id($id){
		global $db;
		
		$sql = "SELECT * FROM Measure ";
		$sql .= "WHERE id='" . $id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		$measure = mysqli_fetch_assoc($result);
		return $measure; // returns an assoc. array

	}
	
	function find_all_ingredients(){
		global $db;
		$sql = "SELECT * FROM Ingredient ";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;		
	}
	function find_ingredient_by_id($id){
		global $db;
		
		$sql = "SELECT * FROM Ingredient ";
		$sql .= "WHERE id='" . $id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		$ingredient = mysqli_fetch_assoc($result);
		return $ingredient; // returns an assoc. array

	}
	function find_directions_by_id($id){
		global $db;
		
		$sql = "SELECT * FROM Directions ";
		$sql .= "WHERE id='" . $id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		$directions = mysqli_fetch_assoc($result);
		return $directions; // returns an assoc. array

	}
	function find_all_recipedirections_by_recipe_id($recipe_id){
		global $db;
		
		$sql = "SELECT * FROM RecipeDirections ";
		$sql .= "WHERE recipe_id='" . $recipe_id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;
	}		
	function find_all_recipeingredient_by_recipe_id($recipe_id){
		global $db;
		
		$sql = "SELECT * FROM RecipeIngredient ";
		$sql .= "WHERE recipe_id='" . $recipe_id . "'";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;
	}
	function insert_recipe($recipe){
		global $db;	
	
		$sql = "INSERT INTO Recipe ";
		$sql .= "(name, description) ";
		$sql .= "VALUES (";
		$sql .= "'" . $recipe['name'] . "',";
		$sql .= "'" . $recipe['description'] . "'";
		$sql .= "); ";
		$sql .= "INSERT INTO Ingredient ";
		$sql .= "(name) ";
		$sql .= "VALUES (";
		$sql .= "'" . $recipe['ingredient1'] . "'";
		$sql .= ");";
		$sql .= "INSERT INTO RecipeIngredient ";
		$sql .= "(recipe_id, ingredient_id, measure_id, amount) ";
		$sql .= "VALUES (";
		$sql .= "'" . $recipe['recipe_id'] . "',";
		$sql .= "'" . $recipe['ingredient_id'] . "',";
		$sql .= "'" . $recipe['measure_id'] . "',";
		$sql .= "'" . $recipe['amount'] . "'";
		$sql .= ");";	
		$result = mysqli_multi_query($db, $sql);
		// For INSERT statements, $result is true/false
		if ($result){
			return true;
		} else {
			//INSERT failed
			echo mysqli_error($db);
			db_disconnect($db);
			exit;	
		}
	}
	
	function update_subject($subject){
		global $db;
		
		$sql = "UPDATE subjects SET ";
		$sql .= "menu_name='" . $subject['menu_name'] . "', ";
		$sql .= "position='" . $subject['position'] . "', ";
		$sql .= "visible='" . $subject['visible'] . "' ";
		$sql .= "WHERE id='" . $subject['id'] . "' ";
		$sql .= "LIMIT 1";
	
		$result = mysqli_query($db, $sql);
		// For UPDATE statement, $result is true/false
		if ($result){
			return true;	
		} else {
			//UPDATE failed
			echo mysqli_error($db);
			db_disconnect($db);
			exit;
		}	
	}	
		
	function find_all_pages(){
		global $db;
		
		$sql = "SELECT * FROM pages ";
		$sql .= "ORDER BY subject_id ASC, position ASC";
		//echo $sql . " <br />";
		$result = mysqli_query($db, $sql);
		confirm_result_set($result);
		return $result;
	}
				
?>	