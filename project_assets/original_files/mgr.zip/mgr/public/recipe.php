<?php require_once('../private/initialize.php'); 
	
	$id = $_GET['id'] ?? ''; //PHP > 7.0
	$recipe_id = $id;	
	$recipe = find_recipe_by_id($id);
	$recipeingredient_set = find_all_recipeingredient_by_recipe_id($recipe_id);
	$recipedirections_set = find_all_recipedirections_by_recipe_id($recipe_id);
	 
		
?>
<?php  include(SHARED_PATH. '/header.php');?>
<?php  include(SHARED_PATH. '/banner.php');?>

<div class="container">
	<div class="row separator"></div>	
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<div class="col-sm-4"><img src="img/_default_img.png" alt="" width="" height="" border="0" /></div>
			<div class="col-sm-6 col-sm-offset-2"><h5><?php echo $recipe['name'];	 ?></h5><?php echo $recipe['description'];	?>	 <p><a href="<?php echo url_for('edit_recipes.php?id=' . h(u($recipe['id'])));?>">Edit</a> | Delete</p>
	<div class="row separator"></div>
		<div class="row col-sm">
			<ul>
			<?php 	
			while($recipeingredient = mysqli_fetch_assoc($recipeingredient_set)){
				$ingredient = find_ingredient_by_id($recipeingredient['ingredient_id']);
				$measure = find_measure_by_id($recipeingredient['measure_id']);
			?>
		
				<li><?php echo $recipeingredient['amount'] . ' ' . $measure['name'] . ' ' . $ingredient['name'];	?>	</li>	
				<?php 	}  ?>	
				</ul>
				
				</div>		
		</div></div>
	</div>
	<div class="row separator"></div>
	<div class="row">
			<div class="col-sm-6 col-sm-offset-3 underline-black"></div>	
	</div>
	<div class="row separator"></div>
	<div class="row">
			<div class="col-sm-8 col-sm-offset-2"></div>
			<div class="col-sm-6 col-sm-offset-3">
			<ol>
			<?php 	
			while($recipedirections = mysqli_fetch_assoc($recipedirections_set)){
				$directions = find_directions_by_id($recipedirections['directions_id']);
			?>
		
				<li><?php echo $directions['name'];	?>	</li>	
				<?php 	}  ?>	
				</ol>
			</div>	
	</div>

<?php include(SHARED_PATH. '/footer.php');?>