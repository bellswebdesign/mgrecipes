<?php require_once('../private/initialize.php'); 

  $recipe_set = find_all_recipes();
    	

  include(SHARED_PATH. '/header.php');
  include(SHARED_PATH. '/banner.php');

while($recipe = mysqli_fetch_assoc($recipe_set)) { 
?>
<div class="container">
	<div class="row separator"></div>	
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<div class="col-sm-4"><img src="img/_default_img.png" alt="" width="" height="" border="0" /></div>
			<div class="col-sm-6 col-sm-offset-2"><h5><?php echo $recipe['name'];?></h5>
<?php echo $recipe['description'];	?><br />	
<?php echo $recipe['instructions'];	?>		

<a href="<?php echo url_for('recipe.php?id=' . h(u($recipe['id'])));?>	">View</a> | <a href="<?php echo url_for('edit_recipes.php?id=' . h(u($recipe['id'])));?>	">Edit</a> | Delete</p></div>		
		</div>
	</div>
		
	<div class="row">
			<div class="col-sm-6 col-sm-offset-3 underline-black"></div>	
	</div>
</div>
<?php 	}?>
	<?php
      mysqli_free_result($recipe_set);
    ?>


<?php include(SHARED_PATH. '/footer.php');?>