<?php require_once('../private/initialize.php'); 
	
if (!isset($_GET['id'])){
	redirect_to(url_for('all_recipes.php'));	
}	
$id = $_GET ['id'];

	

if (is_post_request()){	
	// Handle form value sent by new.php
	$recipe = [];
	$recipe['id'] = $id;
	$recipe['name'] = $_POST['name'] ??'';
	$recipe['description'] = $_POST['description'] ??'';
	//$recipe['visible'] = $_POST['visible'] ??'';	
	
	
	$result = update_subject($subject);
	redirect_to(url_for('recipe.php?id=' . $id));

		
} else {
	$recipe = find_recipe_by_id($id);
	$recipeingredient_set = find_all_recipeingredient_by_recipe_id($recipe['id']);
	$recipe_set = find_all_recipes();
	$recipe_count = mysqli_num_rows($recipe_set);
	mysqli_free_result($recipe_set);	
}
?>
<?php  include(SHARED_PATH. '/header.php');?>
<div class="jumbotron">
	<div class="row"><div class="col-md-3 col-md-offset-4 underline">
		<h2>EDIT RECIPE</h2>
	</div>	</div>
	
	
	<form>	
	<div class="row">
 		<div class="col-md-5 col-md-offset-3 ">
  			<div class="input-group">
  				<input type="text" class="form-control add-title" placeholder="Title" aria-describedby="sizing-addon1" value="<?php echo h($recipe['name']);	?>	">
  			</div>
  		</div>
	</div>
</div>
	<div class="row ">
	  <div class="col-md-3 col-md-offset-2 expadding">
	  	<h1 class="textcolororg">Description <span class="glyphicon glyphicon-question-sign" style="color: #f57e20;"></span></h1>	
	  </div>
	</div>
	<div class="row">
	  <div class="col-md-7 col-md-offset-2 expadding">
	  	<textarea  placeholder="Text input" class="form-control add-descr" rows="7"><?php echo $recipe['description'];	?>	</textarea>
	  </div>
	</div>
	
	<div class="row">
	  <div class="col-md-3 col-md-offset-2 expadding"><h1 class="textcolororg">Ingredients <span class="glyphicon glyphicon-question-sign" style="color: #f57e20;"></span></h1></div>
	</div>
	<div class="row">
	  	<div class="col-xs-1 col-md-offset-7 expadding textright"><h5 style="font-size: 14px">Serving Size</h5></div>
	  <div class="col-xs-2 expadding"><input type="text" class="form-control add-secr" placeholder="4" aria-describedby="sizing-addon1"></div>
	</div>
	<div class="row">
	  <div class="col-md-7 col-md-offset-2">
	  <table class="table table-striped">
	  <?php 	
			while($recipeingredient = mysqli_fetch_assoc($recipeingredient_set)){
				$ingredient = find_ingredient_by_id($recipeingredient['ingredient_id']);
				$measure = find_measure_by_id($recipeingredient['measure_id']);
			?>
	  	<tr class="trowlgray">
	  		<td class="smalltcom">
	  			<input type="" value="<?php echo $recipeingredient['amount']; ?>	" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="smalltcom">
	  			<input type="" value="<?php echo $measure['name'];	?>	" class="form-control trowlgray" aria-describedby="sizing-addon1"></td>
	  		<td class="blanktcom">
	  		</td>
	  		<td>
	  			<input type="" class="form-control trowlgray" value="<?php echo $ingredient['name'];	?>	" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="exsmalltcom"><a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a>
	  		</td>	
	  	</tr>
	  	<?php }?>	
	  </table>
	  </div>
	  <div class="col-md-3 col-md-offset-8 textcolororg "><h5>+ADD ANOTHER</h5></div>	
	</div>
	
	<div class="row">
	  <div class="col-md-3 col-md-offset-2 expadding"><h1 class="textcolororg">Directions <span class="glyphicon glyphicon-question-sign" style="color: #f57e20;"></span></h1></div>
	</div>
	<div class="row">
	  <div class="col-xs-1 col-md-offset-4 expadding textright"><h5 style="font-size: 14px">Prep</h5></div>
	  <div class="col-xs-1 expadding"><input type="text" class="form-control add-secr add-time" placeholder="20 mins" aria-describedby="sizing-addon1"></div>
	  <div class="col-xs-1 col-xs-offset-1 expadding textright"><h5 style="font-size: 14px">Cook</h5></div>
	  <div class="col-xs-1 expadding"><input type="text" class="form-control add-secr add-time" placeholder="4 hours" aria-describedby="sizing-addon1"></div>
	</div>
	
	<div class="row">
	  <div class="col-md-7 col-md-offset-2">
	  <table class="table table-striped">
	  	<tr class="trowlgray">
	  		<td class="smalltcom"><div class="circleBase">1</div></td>
	  		<td><input type="" class="form-control trowlgray" placeholder="Pre-heat Oven to 425." aria-describedby="sizing-addon1"></td>
	  		<td class="exsmalltcom"><a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a></td>	
	  	</tr>
	  	<tr class="trowdgray">
	  		<td class="smalltcom"><div class="circleBase">2</div></td>
	  		<td><input type="" class="form-control trowdgray" aria-describedby="sizing-addon1"></td>
	  		<td class="exsmalltcom"><a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a></td>	
	  	</tr>
	  	<tr class="trowlgray">
	  		<td class="smalltcom"><div class="circleBase">3</div></td>
	  		<td><input type="" class="form-control trowlgray" aria-describedby="sizing-addon1"></td>
	  		<td class="exsmalltcom"><a href="#"><span class="glyphicon glyphicon-remove-sign" style="color: #f57e20; font-size: 20px;"></span></a></td>	
	  	</tr>
	  </table>
	  </div>
	  <div class="col-md-3 col-md-offset-8 textcolororg "><h5>+ADD ANOTHER</h5></div>	
	</div>
	
	<div class="row">
	<div class="row"><div class="col-md-4 col-md-offset-4 exexpadding ">
		<h4>All done & ready to publish?</h4>
	</div>	
	</div>	
	  <div class="col-md-3 col-md-offset-5 ">
	  	<div class="btn-group">
  <button class="btn btn-default btn-lg bgcolororg xlgbtn" type="button" aria-expanded="false">
    Created
  </button>
  
	  </div></div><div class="row"><div class="col-md-4 col-md-offset-5 ">
				<h4>or, Save as a Draft!</h4>
			</div>	
		</div>
	</div>
	</form>
<?php include(SHARED_PATH. '/footer.php');?>