<?php require_once('../private/initialize.php'); ?>
<?php  include(SHARED_PATH. '/header.php');?>
<?php  include(SHARED_PATH. '/banner.php');?>

<div class="col-md-3 pull-left">
		<div class="row">	
			<div class="col-sm-9">		
				<h4>Left side bar</h4>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vitae lorem in orci vehicula suscipit.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-9">		
				<h4>Popular recipes</h4>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vitae lorem in orci vehicula suscipit.</p>
			</div>
		</div>
	</div>	
<!-- Right Side bar -->	
	<div class="col-md-3 pull-right">
		<div class="row">	
			<div class="col-sm-9">		
				<h4>Right side bar</h4>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vitae lorem in orci vehicula suscipit.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-9">		
				<h4>Right side bar</h4>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vitae lorem in orci vehicula suscipit.</p>
			</div>
		</div>	</div>
<!-- Main -->	
<div class="row">
	<div class="col-md-5">
		<h4>Main</h4>
		<img src="img/_default_img.png" alt="" width="" height="" border="0" />
			<div class="col-md-8"><h5>Healthy Asian Chicken Dish</h5>This and that and this. Talk about something to fill space and also filler space of filler information to choose what to fill upon filling. More and more and more stuff.</div>		
	</div>	
</div>
<div class="col-md-5 col-sm-offset-3">
		<h4>2nd Main</h4>	
		<img src="img/_default_img.png" alt="" width="" height="" border="0" /></div>
			<div class="col-sm-4 col-sm-offset-3"><h5>Healthy Asian Chicken Dish</h5>This and that and this. Talk about something to fill space and also filler space of filler information to choose what to fill upon filling. More and more and more stuff.</div>
	</div>	
</div>	

<div class="clearfix"></div>
<!-- Grid system Example: Stacked-to-horizontal -->
<div class="show-grid">
<div class="row">
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
  <div class="col-md-1">.col-md-1</div>
</div>
<div class="row">
  <div class="col-md-8">.col-md-8</div>
  <div class="col-md-4">.col-md-4</div>
</div>
<div class="row">
  <div class="col-md-4">.col-md-4</div>
  <div class="col-md-4">.col-md-4</div>
  <div class="col-md-4">.col-md-4</div>
</div>
<div class="row">
  <div class="col-md-6">.col-md-6</div>
  <div class="col-md-6">.col-md-6</div>
</div>
</div>

<?php include(SHARED_PATH. '/footer.php');?>