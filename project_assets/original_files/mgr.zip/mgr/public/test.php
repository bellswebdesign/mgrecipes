<?php require_once('../private/initialize.php'); 
	
	$id = "2";
	$recipe_id = "2";	
	$recipe = find_recipe_by_id($id);
	//var_dump($recipe);
	$ingredient = find_all_recipeingredient_by_recipe_id($recipe_id);
	//$recipeingredient = [];
	//$recipeingredient = find_all_recipeingredient_by_recipe_id($recipe_id);
	echo "<br />	";	
	//var_dump($ingredient);
	 	

?>




<?php include(SHARED_PATH. '/footer.php');?>