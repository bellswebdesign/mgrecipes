<?php require_once('../private/initialize.php'); ?>
<?php  include(SHARED_PATH. '/header.php');
	

if (is_post_request()){	
	// Handle form value sent by new.php
	$recipe = [];
	$recipe['name'] = $_POST['name'] ??'';
	$recipe['description'] = $_POST['description'] ??'';
	$recipe['ingredient'] = $_POST['ingredient'] ??'';
	$recipe['ingredient_id'] = $_POST['ingredient_id'] ??'';
	$recipe['measure_id'] = $_POST[$recipe['measure_id']] ??'';
	$recipe['amount'] = $_POST['amount'] ??'';
	echo $recipe['measure_id'];		
	//$result = insert_recipe($recipe);
  if($result === true) {
	$new_id = mysqli_insert_id($db);
	redirect_to(url_for('recipe.php?id=' . 	$new_id));
	} else { 
		$recipe = [];
		$recipe['name'];
		$recipe['description'];
		$recipe['ingredient'];
		$recipe['recipe_id'];
		$recipe['ingredient_id'];
		$recipe['measure_id'];
		$recipe['amount'];
	}
}
?>	
<div class="jumbotron">
	<div class="row"><div class="col-md-3 col-md-offset-4 underline">
		<h2>ADD RECIPE</h2>
	</div>	</div>
	
	
	<form action="<?php echo url_for('add_recipe.php');?>" method="post">	
	<div class="row">
 		<div class="col-md-5 col-md-offset-3 ">
  			<div class="input-group">
  				<input name="name" type="text" class="form-control add-title" placeholder="Title" aria-describedby="sizing-addon1">
  			</div>
  		</div>
	</div>
</div>
	<div class="row ">
	  <div class="col-md-3 col-md-offset-2 expadding">
	  	<h1 class="textcolororg">Description <span class="glyphicon glyphicon-question-sign" style="color: #f57e20;"></span></h1>	
	  </div>
	</div>
	
	<div class="row">
	  <div class="col-md-7 col-md-offset-2 expadding">
	  	<textarea  name="description" placeholder="Text input" class="form-control add-descr" rows="7"></textarea>
	  </div>
	</div>
	
	<div class="row">
	  <div class="col-md-3 col-md-offset-2 expadding"><h1 class="textcolororg">Ingredients <span class="glyphicon glyphicon-question-sign" style="color: #f57e20;"></span></h1></div>
	</div>
	<div class="row">
	  	<div class="col-xs-1 col-md-offset-7 expadding textright"><h5 style="font-size: 14px">Serving Size</h5></div>
	  <div class="col-xs-2 expadding"><input name="serving_size" type="text" class="form-control add-secr" placeholder="4" aria-describedby="sizing-addon1"></div>
	</div>
	<div class="row">
	  <div class="col-md-7 col-md-offset-2">
	  
<table class="table table-striped">
	  
	  	<tr class="trowlgray">
	  		<td class="smalltcom">
	  			<input type="text" name="amount" placeholder="4" class="form-control trowlgray" aria-describedby="sizing-addon1">
	  		</td>
	  		<td class="smalltcom">
	  			<select name="measure" class="form-control trowlgray">
            <?php
            $measure_set = find_all_measures();
            while($measure = mysqli_fetch_assoc($measure_set)) {
            	$recipe['measure_id'] = h($measure['id']);
              echo "<option" ;
              echo " name=\"" . $recipe['measure_id'] . "\"" ;
              echo " value=\"" . h($measure['id']) . "\"";
              echo ">" . h($measure['name']) . "</option>";	
            }
            echo $recipe['measure_id'];	
            mysqli_free_result($measure_set);
            
            ?>
          </select>
	  		</td>
	  		<td class="blanktcom"></td>
	  		<td>
	  		<select name="ingredient" class="form-control trowlgray">
            <?php
            $ingredient_set = find_all_ingredients();
            while($ingredient = mysqli_fetch_assoc($ingredient_set)) {
              echo "<option value=\"" . h($ingredient['id']) . "\"";
              echo ">" . h($ingredient['name']) . "</option>";
            }
            mysqli_free_result($ingredient_set);
            
            ?>
          </select>
	  		</td>	
	  	</tr>
	  </table>	  
	 </div>
	  <div class="col-md-3 col-md-offset-8 textcolororg ">
	  	<h5>+ADD ANOTHER</h5></div>	
	  </div>
	
	<div class="row">
	<div class="row"><div class="col-md-4 col-md-offset-4 exexpadding ">
		<h4>All done & ready to publish?</h4>
	</div>	
	</div>	
	  <div class="col-md-3 col-md-offset-5 ">
	  	<div class="btn-group">
  <input type="submit" class="btn btn-default btn-lg bgcolororg xlgbtn" type="button" aria-expanded="false" value="Create" />
  
  
	  </div></div><div class="row"><div class="col-md-4 col-md-offset-5 ">
				<h4>or, Save as a Draft!</h4>
			</div>
	  </form>	
		</div>
	</div>
<?php include(SHARED_PATH. '/footer.php');?>